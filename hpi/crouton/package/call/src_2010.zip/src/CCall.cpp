// CCall

#include "hsp3plugin_custom.h"
#include "mod_makepval.h"

#include "CCall.h"
#include "CArgData.h"
#include "CPrmInfo.h"
#include "CPrmStk.h"

#include "cmd_sub.h"

//##############################################################################
//                ��`�� : CCall
//##############################################################################
//------------------------------------------------
// �\�z
//------------------------------------------------
CCall::CCall()
	: mLb           ( NULL )
	, mpPrm         ( NULL )
	, mpRetVal      ( NULL )
	, mppPrmStack   ( NULL )
	, mpOldPrmStack ( NULL )
	, mpPrmStack    ( NULL )
{
	mpArg = new CArgData( this );
}


//------------------------------------------------
// ���
//------------------------------------------------
CCall::~CCall()
{
	delete mpArg; mpArg = NULL;
	
	freeRetVal();
	
	// prmstack �����ɖ߂�
	if ( mpPrmStack != NULL ) {
		resetPrmStack();
		
		delete mpPrmStack; mpPrmStack = NULL;
	}
	
	return;
}


//##########################################################
//    �R�}���h����
//##########################################################
//------------------------------------------------
// �G�C���A�X
//------------------------------------------------
void CCall::alias(PVal* pval, int iArg) const
{
	if ( !numrg(iArg, 0, mpArg->getCntArg() - 1) ) return;
	
	// �G�C���A�X�ϐ����A�����l�̃N���[���Ƃ���
	PVal*  pvalArg = mpArg->getArgPVal( iArg );		// �����̕ϐ�
	APTR   aptr    = mpArg->getArgAptr( iArg );
	
	// dup �����ŃN���[����
	HspVarCoreDup( pval, pvalArg, aptr );
	
	return;
}


//------------------------------------------------
// �������f�[�^���擾����
// 
// @result : ���������i�[���� PVal �ւ̃|�C���^
//------------------------------------------------
PVal* CCall::getArgv(int iArg) const
{
	PVal* pval = mpArg->getArgPVal( iArg );
	
	if ( pval == NULL ) {
		pval = PVal_getDefault();	// ����l���g��
	}
	
	return pval;
}


//##########################################################
//    ����
//##########################################################
//------------------------------------------------
// call
//------------------------------------------------
void CCall::call(void)
{
	code_call( mLb );
	return;
}


//------------------------------------------------
// ���x���̐ݒ�
//------------------------------------------------
void CCall::setLabel(label_t lb)
{
	mLb = lb;
	return;
}


//################################################
//    �������f�[�^�̐ݒ�
//################################################
//------------------------------------------------
// this �ϐ���ݒ肷��
//------------------------------------------------
void CCall::setThis(PVal* pval, APTR aptr)
{
	mpArg->setThis( pval, aptr );
	return;
}


//------------------------------------------------
// ������ǉ����� ( �Q�Ɠn�� )
//------------------------------------------------
void CCall::addArgByRef(PVal* pval)
{
	mpArg->addArgByRef( pval );
	return;
}


//------------------------------------------------
// ������ǉ����� ( �l�n�� )
//------------------------------------------------
void CCall::addArgByVal(PVal* pval)
{
	mpArg->addArgByVal( pval );
	return;
}


//------------------------------------------------
// 
//------------------------------------------------

//------------------------------------------------
// ����Ȃ�����������l�ŕ₤
//------------------------------------------------
void CCall::completeArg(void)
{
	if ( !usesPrmInfo() ) return;
	
	// �ϒ������ł͂Ȃ��̂ɁA��������������
	if ( !mpPrm->isFlex() && mpPrm->cntPrms() < mpArg->getCntArg() ) {
		puterror( HSPERR_TOO_MANY_PARAMETERS );
	}
	
	// ����l�Ŗ��߂�A���܂�Ȃ���΃G���[
	for ( int i = mpArg->getCntArg()
		; i < mpPrm->cntPrms()
		; ++ i
	) {
		// �ȗ��l or �G���[
		mpArg->addArgByVal(
			mpPrm->getDefaultArg(i)
		);
	}
	return;
}

//################################################
//    ���������
//################################################
//------------------------------------------------
// CPrmInfo �̐ݒ�
//------------------------------------------------
void CCall::setPrmInfo(CPrmInfo* pPrmInfo)
{
	if ( usesPrmInfo() ) return;
	
	mpPrm = pPrmInfo;
	setLabel( pPrmInfo->getLabel() );
	return;
}

//################################################
//    �Ԓl
//################################################
//------------------------------------------------
// �Ԓl�̐ݒ�
//------------------------------------------------
void CCall::setRetVal(void* pRetVal, vartype_t vt)
{
	if ( mpRetVal == NULL ) {
		mpRetVal = new PVal;
		PVal_init( mpRetVal, vt );
	}
	
	// ���
	code_setva( mpRetVal, 0, vt, pRetVal );
	return;
}

//################################################
//    prmstack
//################################################
//------------------------------------------------
// prmstack �̐ݒ�
//------------------------------------------------
void CCall::setPrmStack(void** ppPrmStack)
{
	mppPrmStack   = ppPrmStack;
	mpOldPrmStack = *mppPrmStack;	// �ȑO�� prmstack �̏��
	mpPrmStack    = new CPrmStk( getCntArg() + 2 );	// this + ������Ƒ傫��
	
	CreatePrmStack( mpPrmStack, this );
	
	// prmstack �̕ύX
	*mppPrmStack  = mpPrmStack->getptr();
	return;
}


//##########################################################
//    �擾
//##########################################################
//------------------------------------------------
// 
//------------------------------------------------

//################################################
//    �������f�[�^�̎擾
//################################################
//------------------------------------------------
// �������̐�
//------------------------------------------------
int CCall::getCntArg(void) const
{
	return mpArg->getCntArg();
}


//------------------------------------------------
// this ���g���Ă��邩
//------------------------------------------------
bool CCall::usesThis(void) const
{
	return mpArg->usesThis();
}


//------------------------------------------------
// this �ϐ�
//------------------------------------------------
MPVarData *CCall::getThis(void) const
{
	return mpArg->getThis();
}


//------------------------------------------------
// �������f�[�^�� pval
//------------------------------------------------
PVal* CCall::getArgPVal(int iArg) const
{
	return mpArg->getArgPVal( iArg );
}


//------------------------------------------------
// �������f�[�^�� pval �� aptr
//------------------------------------------------
APTR CCall::getArgAptr(int iArg) const
{
	return mpArg->getArgAptr( iArg );
}


//------------------------------------------------
// ���������
//------------------------------------------------
int CCall::getArgInfo(ARGINFOID id, int iArg) const
{
	// �����Ȃ�A�Ăяo���S�̂Ɋւ�����𓾂�
	if ( iArg < 0 ) {
		return mpArg->getArgInfo(id);
		
	// �������Ƃ̏��𓾂�
	} else {
		// id �͈̔̓`�F�b�N
		if ( !numrg( id, 0, ARGINFOID_MAX - 1 ) ) {
			puterror( HSPERR_ILLEGAL_FUNCTION );	// "�����̒l���ُ�ł�"
		}
		
		return mpArg->getArgInfo(id, iArg);
	}
}


//################################################
//    ���������̎擾
//################################################
//------------------------------------------------
// �������^�C�v
//------------------------------------------------
int CCall::getPrmType(int iPrm) const
{
	return usesPrmInfo()
		? mpPrm->getPrmType(iPrm)
		: PRM_TYPE_NONE;
}


//------------------------------------------------
// �f�t�H���g�l
//------------------------------------------------
PVal* CCall::getDefaultArg(int iPrm) const
{
	return mpPrm->getDefaultArg(iPrm);
}


//------------------------------------------------
// �������������ǂ���
//------------------------------------------------
void CCall::checkCorrectArg(const PVal* pvArg, int iArg, bool bByRef) const
{
	mpPrm->checkCorrectArg( pvArg, iArg, bByRef );
	return;
}


//################################################
//    �Ԓl�f�[�^�̎擾
//################################################
//------------------------------------------------
// �Ԓl�̎��̃|�C���^�𓾂�
//------------------------------------------------
void* CCall::getResult(void) const
{
	PVal* pvResult   = getRetVal();
	HspVarProc* vp = exinfo->HspFunc_getproc( pvResult->flag );
	
	return vp->GetPtr( pvResult );
}


//------------------------------------------------
// �Ԓl�� PVal �𓾂�
//------------------------------------------------
PVal* CCall::getRetVal(void) const
{
	return mpRetVal;
}


//##########################################################
//    ���������o�֐�
//##########################################################
//------------------------------------------------
// �Ԓl(mpRetVal)�̉��
//------------------------------------------------
void CCall::freeRetVal(void)
{
	if ( mpRetVal == NULL ) return;
	
	// ���g�̉��
	PVal_free( mpRetVal );
	
	// mpRetVal ���̂̉��
	delete mpRetVal; mpRetVal = NULL;
	
	return;
}


//------------------------------------------------
// prmstack �����ɖ߂�
//------------------------------------------------
void CCall::resetPrmStack(void)
{
	*mppPrmStack = mpOldPrmStack;
	return;
}


//------------------------------------------------
// 
//------------------------------------------------
