// prmstack ����N���X

#include "CPrmStk.h"

#define mem_alloc  (hspmalloc)
#define mem_expand (hspexpand)
#define mem_free   (hspfree)

//##############################################################################
//                ��`�� : CPrmStk
//##############################################################################
//------------------------------------------------
// �\�z
//------------------------------------------------
CPrmStk::CPrmStk( size_t defCnt )
	: mbufSize( defCnt * sizeof(MPVarData) )
	, musingSize( 0 )
{
	mp = (char* )mem_alloc( mbufSize * sizeof(char) );
}

//------------------------------------------------
// ���
//------------------------------------------------
CPrmStk::~CPrmStk()
{
	if ( mp != NULL ) { mem_free(mp); mp = NULL; }
	mbufSize   = 0;
	musingSize = 0;
	return;
}


//------------------------------------------------
// �X�^�b�N�̃|�C���^���擾
//------------------------------------------------
void*  CPrmStk::getptr(void) const
{
	return mp;
}


//------------------------------------------------
// PVal�f�[�^���v�b�V������
//------------------------------------------------
void CPrmStk::pushPVal(PVal* pval, APTR aptr)
{
	pushValue(pval);
	pushValue(aptr);
	return;
}


void CPrmStk::pushPVal(MPVarData *pVarDat)
{
	pushPVal( pVarDat->pval, pVarDat->aptr );
	return;
}


//------------------------------------------------
// �������m��
//------------------------------------------------
void CPrmStk::reserve(size_t reserveCnt)
{
	size_t reserveSize = reserveCnt * sizeof(MPVarData);
	
	stkRealloc( reserveSize );
	
	return;
}


//##########################################################
//    ���������o�֐�
//##########################################################
//------------------------------------------------
// �X�^�b�N�Ċm��
//------------------------------------------------
void CPrmStk::stkRealloc(size_t allocSize)
{
	if ( mbufSize < allocSize ) {
		mbufSize = allocSize;
		mp       = (char* )mem_expand( mp, mbufSize * sizeof(char) );
	}
	return;
}


//------------------------------------------------
// �X�^�b�N�g��
//------------------------------------------------
void CPrmStk::stkExpand(size_t expandSize)
{
	stkRealloc( mbufSize + expandSize );
	return;
}
