// call - SubCommand

#include <windows.h>
#include <stack>
#include <map>
#include "hsp3plugin_custom.h"
#include "mod_varutil.h"
#include "mod_utility.h"

#include "cmd_sub.h"

#include "CCaller.h"
#include "CCall.h"
#include "CPrmInfo.h"
#include "StDest.h"

#include "vt_caller.h"

//##########################################################
//        �O���[�o���ϐ�
//##########################################################
// �Ăяo�������̃X�^�b�N
static std::stack<CCall*> g_stkCall;

// �֐��Ԓl
static PVal* g_respval = NULL;

// �������錾�f�[�^
static std::map<label_t, CPrmInfo> g_lbprmlist;

//##############################################################################
//                Call ����������
//##############################################################################

//##########################################################
//       �Ԓl�f�[�^
//##########################################################
//------------------------------------------------
// ���O�̃��x���֐��̕Ԓl���擾
//------------------------------------------------
PVal* GetCallRetVal(void)
{
	return g_respval;
}

//##########################################################
//       �Ǝ��X�^�b�N
//##########################################################
//------------------------------------------------
// �����X�^�b�N�Ɉ�ςފ֐�
//------------------------------------------------
void PushCallStack(CCall* pCall)
{
	g_stkCall.push( pCall );
	return;
}

//------------------------------------------------
// �����X�^�b�N�̃g�b�v��Ԃ�
// 
// @ �X�^�b�N����Ȃ� NULL ��Ԃ��B
//------------------------------------------------
CCall* TopCallStack(void)
{
	if ( g_stkCall.empty() ) return NULL;
	
	return g_stkCall.top();
}

//------------------------------------------------
// �����X�^�b�N����߂��֐�
//------------------------------------------------
void PopCallStack(void)
{
	if ( g_stkCall.empty() ) puterror( HSPERR_STACK_OVERFLOW );
	
	g_stkCall.pop();	// ����
	return;
}

//------------------------------------------------
// �����X�^�b�N�����ׂĉ������֐�
//------------------------------------------------
void FreeCallStack(void)
{
	// ��ɂȂ�܂ŉ������
	while ( !g_stkCall.empty() ) {
		PopCallStack();
	}
	return;
}

//##########################################################
//       ���������X�g
//##########################################################
//------------------------------------------------
// ���������X�g�̐錾
//------------------------------------------------
void DeclarePrmInfo(const CPrmInfo& prminfo)
{
	if ( GetPrmInfo(prminfo.getLabel()) != NULL ) {
		dbgout("���d��`�ł��B");
		puterror( HSPERR_ILLEGAL_FUNCTION );
	}
	
	g_lbprmlist.insert(
		std::map<label_t, CPrmInfo>::value_type(
			prminfo.getLabel(), prminfo
		)
	);
	return;
}

//------------------------------------------------
// �������̎擾
//------------------------------------------------
CPrmInfo* GetPrmInfo(label_t lb)
{
	if ( g_lbprmlist.count(lb) == 0 ) {
		return NULL;
	}
	
	return &( g_lbprmlist.find( lb )->second );
}

//------------------------------------------------
// CPrmInfo <- ���ԃR�[�h
// 
// @ label, (prmlist)
//------------------------------------------------
void CreatePrmInfo(CPrmInfo* pPrmInfo)
{
	if ( pPrmInfo == NULL ) return;
	
	StDest dest;
	
	code_getdest( dest );
	
	// deffid �Ȃ��
	if ( dest.type == DestType_Deffid ) {
		CreatePrmInfo( pPrmInfo, GetSTRUCTDAT( dest.deffid ) );
		return;
	}
	
	// ���ԃR�[�h���牼�������X�g�����o��
	label_t lbDst = dest.lb;
	bool    bFlex = false;
	
	CPrmInfo::prmlist_t prmlist;
	prmlist.reserve( 6 );		// �����Ă� (5 + 1) ���Ȃ�
	
	// ���������X�g
	while ( code_isNextArg() )
	 {
		int prmtype = code_getprmtype( PRM_TYPE_NONE );
		if ( prmtype == PRM_TYPE_NONE ) continue;	// �ȗ������͖���
		
		prmlist.push_back( prmtype );
	}
	
	// CPrmInfo �ɕϊ�
	pPrmInfo->setLabel  ( lbDst );
	pPrmInfo->setFlex   ( bFlex );
	pPrmInfo->setPrmlist( prmlist );
	
	return;
}

//------------------------------------------------
// CPrmInfo <- STRUCTDAT
//------------------------------------------------
void CreatePrmInfo(CPrmInfo* pPrmInfo, const STRUCTDAT* pStDat)
{
	if ( pPrmInfo == NULL || pStDat == NULL ) return;
	
	CPrmInfo::prmlist_t prmlist;
	
	prmlist.reserve( pStDat->prmmax );
	
	STRUCTPRM* pStPrm = &ctx->mem_minfo[pStDat->prmindex];
	
	for ( int i = 0; i < pStDat->prmmax; ++ i ) {
		
		// MPTYPE_** ��������������B
		switch ( pStPrm->mptype ) {
			case MPTYPE_LABEL:       prmlist.push_back( HSPVAR_FLAG_LABEL  ); break;
			case MPTYPE_LOCALSTRING: prmlist.push_back( HSPVAR_FLAG_STR    ); break;
			case MPTYPE_DNUM:        prmlist.push_back( HSPVAR_FLAG_DOUBLE ); break;
			case MPTYPE_INUM:        prmlist.push_back( HSPVAR_FLAG_INT    ); break;
			case MPTYPE_SINGLEVAR:   prmlist.push_back( PRM_TYPE_VAR       ); break;
			case MPTYPE_ARRAYVAR:    prmlist.push_back( PRM_TYPE_ARRAY     ); break;
			case MPTYPE_MODULEVAR:   prmlist.push_back( PRM_TYPE_MODVAR    ); break;
			
			default:
				break;
		}
		++ pStPrm;
	}
	
	pPrmInfo->setLabel  ( ctx->mem_mcs + ctx->mem_ot[pStDat->otindex] );
	pPrmInfo->setPrmlist( prmlist );
	pPrmInfo->setFlex   ( false );
	
	return;
}

//------------------------------------------------
// CPrmStk �̐ݒ�
// 
// @ from CArgInfo
//------------------------------------------------
void CreatePrmStack(CPrmStk* pPrmStack, const CCall* pCall)
{
	if ( pPrmStack == NULL || pCall == NULL ) return;
	
	pPrmStack->reserve( pCall->getCntArg() + 1 );
	
	// this �|�C���^��擪�ɐς�
	if ( pCall->usesThis() ) {
		pPrmStack->pushPVal( pCall->getThis() );
	}
	
	CPrmInfo* pPrmInfo = pCall->getPrmInfo();
	
	// ���������X�g�ʂ�ɐς� ( HSP �Ɠ����`�����g�� )
	if ( pPrmInfo != NULL ) {
		for ( int i = 0; i < pPrmInfo->cntPrms(); ++ i )
		 {
			PVal* pval = pCall->getArgPVal(i);
			
			int prmtype = pPrmInfo->getPrmType(i);
			
			if ( prmtype == HSPVAR_FLAG_LABEL ) {	// HSP���Ŗ���������
				pPrmStack->pushValue( *reinterpret_cast<label_t*>(pval->pt) );
				
			} else if ( prmtype == HSPVAR_FLAG_DOUBLE ) {
				pPrmStack->pushValue( *reinterpret_cast<double*>(pval->pt) );
				
			} else if ( prmtype == HSPVAR_FLAG_INT ) {
				pPrmStack->pushValue( *reinterpret_cast<int*>(pval->pt) );
				
			} else if ( prmtype == HSPVAR_FLAG_STR ) {
				pPrmStack->pushValue( pval->pt );
				
			} else if ( prmtype == PRM_TYPE_VAR
					||  prmtype == PRM_TYPE_ARRAY
					||  prmtype == PRM_TYPE_ANY
			) {
				pPrmStack->pushPVal( pval, pval->offset );
				
			} else if ( prmtype == PRM_TYPE_MODVAR ) {
				FlexValue* pFv    = reinterpret_cast<FlexValue*>( GetPValRealPtr(pval) );
				STRUCTPRM* pStPrm = &ctx->mem_minfo[pFv->customid];
				
				MPModVarData modvardat;
				modvardat.magic = MODVAR_MAGICCODE;
				modvardat.subid = pStPrm->subid;
				modvardat.pval  = pval;
				modvardat.aptr  = pCall->getArgAptr(i);
				
				pPrmStack->pushValue( modvardat );
				
			} else {
				// ��������������
				puterror( HSPERR_INVALID_PARAMETER );
			}
		}
		
	// �^����ꂽ���������ׂĐς�
	} else {
		for ( int i = 0; i < pCall->getCntArg(); ++ i ) {
			PVal* pval = pCall->getArgPVal( i );
			
			// ���ׂ� var/array �̌`���œn��
			pPrmStack->pushPVal( pval, pval->offset );
		}
	}
	
	return;
}

//##########################################################
//       �����擾
//##########################################################
//------------------------------------------------
// �������^�C�v���擾����
//------------------------------------------------
int code_getprmtype( int deftype )
{
	int prmtype = PRM_TYPE_NONE;
	
	// �Ƃ肠�����Ȃɂ��擾����
	int prm = code_getprm();
	if ( prm == PARAM_END || prm == PARAM_ENDSPLIT ) return PRM_TYPE_NONE;
	if ( prm == PARAM_DEFAULT ) return deftype;
	
	switch ( mpval->flag ) {
		// ���l�Ȃ炻�̂܂ܕԂ�
		case HSPVAR_FLAG_INT:
			prmtype = *reinterpret_cast<int*>( mpval->pt );
			break;
			
		// ������ => ���ꕶ���� or �^��( HspVarProc ����擾 )
		case HSPVAR_FLAG_STR:
		{
			prmtype = GetPrmType( mpval->pt );
			
			if ( prmtype == PRM_TYPE_NONE ) {
				puterror( HSPERR_ILLEGAL_FUNCTION );
			}
			break;
		}
		default:
			puterror( HSPERR_TYPE_MISMATCH );
			break;
	}
	return prmtype;
}

//------------------------------------------------
// �W�����v����擾����
//------------------------------------------------
void code_getdest(StDest& dest)
{
	dest.type = DestType_None;
	
	{
		int chk = code_getprm();
		if ( chk <= PARAM_END ) puterror( HSPERR_NO_DEFAULT );
	}
	
	// label
	if ( mpval->flag == HSPVAR_FLAG_LABEL ) {
		dest.lb   = *reinterpret_cast<label_t*>( mpval->pt );
		dest.type = DestType_Label;
		
	// deffid
	} else if ( mpval->flag == HSPVAR_FLAG_INT ) {
		dest.deffid = *reinterpret_cast<int*>( mpval->pt );
		dest.type   = DestType_Deffid;
		
		if ( !isModcmdId(dest.deffid) ) puterror( HSPERR_ILLEGAL_FUNCTION );
		
	// caller
	} else if ( mpval->flag == HSPVAR_FLAG_CALLER ) {
		StCaller* pstCaller = reinterpret_cast<StCaller*>( mpval->pt );
		
		dest = pstCaller->dest;
		
	} else {
		puterror( HSPERR_LABEL_REQUIRED );
	}
	
	return;
}

//------------------------------------------------
// defid ���擾����
// 
// @result: defid (���s�l: 0)
//------------------------------------------------
int code_getdefid(void)
{
	int defid = DefId::make( *type, *val );		// MagicCode ��
	*exinfo->npexflg &= ~EXFLG_2;
	code_skipprm();
	return defid;
}

//##########################################################
//       ���̑�
//##########################################################
//------------------------------------------------
// ���x�����擾����
//------------------------------------------------
label_t GetLabel(StDest& rDest)
{
	switch ( rDest.type ) {
		case DestType_Label:
			return *reinterpret_cast<label_t*>( mpval->pt );
			
		case DestType_Deffid:
			if ( isModcmdId( rDest.deffid ) ) {
				STRUCTDAT* pStDat = GetSTRUCTDAT( rDest.deffid );
				
				return GetLabel_fromOTindex( pStDat->otindex );
			}
			break;
	}
	
	return NULL;
}

//------------------------------------------------
// STRUCTDAT* <- deffid
//------------------------------------------------
STRUCTDAT* GetSTRUCTDAT(int deffid)
{
	STRUCTDAT* pStDat;
	
	if ( isModcmdId(deffid) ) {
		pStDat = &ctx->mem_finfo[ DefId::getCode(deffid) ];
	} else {
		puterror( HSPERR_INVALID_PARAMETER );
	}
	
	return pStDat;
}

//------------------------------------------------
// prmtype ���擾���� (from ������)
// 
// @result: prmtype (���s�l PRM_TYPE_NONE)
//------------------------------------------------
int GetPrmType( const char* s )
{
	{
		HspVarProc* vp = GetHspVarProc( s );
		if ( vp ) return vp->flag;
	}
	
	if ( !strcmp(s, "var"   ) ) return PRM_TYPE_VAR;
	if ( !strcmp(s, "array" ) ) return PRM_TYPE_ARRAY;
	if ( !strcmp(s, "any"   ) ) return PRM_TYPE_ANY;
	if ( !strcmp(s, "modvar") ) return PRM_TYPE_MODVAR;
	if ( !strcmp(s, "..."   ) ) return PRM_TYPE_FLEX;
	if ( !strcmp(s, "flex"  ) ) return PRM_TYPE_FLEX;
	return PRM_TYPE_NONE;
}


//##############################################################################
//                �������֐�
//##############################################################################
//------------------------------------------------
// ���l�͈̔͂𓾂�֐�
//------------------------------------------------
bool numrg( int val, int min, int max )
{
	return ( min <= val && val <= max );
}
