// CCall::CArgData

#include <cstring>

#include "hsp3plugin_custom.h"
#include "mod_makepval.h"

#include "CCall.h"
#include "CArgData.h"
#include "CPrmInfo.h"

extern bool numrg(int val, int min, int max);

#define LengthOf(arr) ( sizeof(arr) / sizeof(arr[0]) )

//#########################################################
//        �R���X�g���N�^�E�f�X�g���N�^
//#########################################################
//------------------------------------------------
// �\�z
//------------------------------------------------
CCall::CArgData::CArgData(CCall* pCall)
	: mpCall        ( pCall )
	, mpArgVal      ( new std::vector<PVal*> )
	, mpIdxRef      ( new std::vector<APTR> )
	, mCntArg       ( 0 )
{
	clearThis();
}


//------------------------------------------------
// ���ʍ\�z
//------------------------------------------------
CCall::CArgData::CArgData(const CCall::CArgData& obj)
{
	opCopy( obj );
	return;
}


//------------------------------------------------
// ���
// 
// @ �f�[�^�̉��
//------------------------------------------------
CCall::CArgData::~CArgData()
{
	// this �f�[�^�̏�����
	clearThis();
	
	// �����E�Ԓl�����ׂĉ������
	freeArgPVal();
	
	return;
}


//#########################################################
//        public�����o�֐��Q
//#########################################################
//------------------------------------------------
// = ( ���� )
//------------------------------------------------
CCall::CArgData& CCall::CArgData::operator = (const CCall::CArgData& obj)
{
	return opCopy( obj );
}


//##########################################################
//    �ݒ�n
//##########################################################
//------------------------------------------------
// this �|�C���^��ݒ肷��
//------------------------------------------------
void CCall::CArgData::setThis(PVal* pvThis, APTR aptr)
{
	mvarThis.pval = pvThis;
	mvarThis.aptr = aptr;
	return;
}

//------------------------------------------------
// ������ǉ����� ( �Q�Ɠn�� )
// 
// @ ���������� -> pval + aptr
// @ �������Ȃ� -> �N���[��
//------------------------------------------------
void CCall::CArgData::addArgByRef(PVal* pval)
{
	PVal* pvalarg;
	
	if ( mpCall->usesPrmInfo() ) {
		pvalarg = pval;
		
	} else {
		pvalarg = new PVal;
		HspVarCoreDup( pvalarg, pval, pval->offset );
	}
	
	mpArgVal->push_back( pvalarg );
	mpIdxRef->push_back( pvalarg->offset );
	mCntArg ++;
	return;
}

//------------------------------------------------
// ������ǉ�����( �l�n�� )
//------------------------------------------------
void CCall::CArgData::addArgByVal(PVal* pval)
{
	PVal* pvalarg    = new PVal;
	HspVarProc* vp = exinfo->HspFunc_getproc( pval->flag );
	
	// �f�[�^�𕡎ʂ���( ������� )
	PVal_init( pvalarg, pval->flag );
	vp->Set(
		pvalarg,
		vp->GetPtr(pvalarg),
		vp->GetPtr(pval)
	);
//	code_setva( pvalarg, 0, pval->flag, vp->GetPtr(pval) );
	
	// �z��Ɋi�[
	mpArgVal->push_back(pvalarg);
	mpIdxRef->push_back(-1);
	mCntArg ++;
	return;
}


//################################################
//    �擾�n
//################################################
//------------------------------------------------
// this �ϐ��� PVal, APTR �𓾂�
//------------------------------------------------
MPVarData *CCall::CArgData::getThis(void) const
{
	return const_cast<MPVarData *>( &mvarThis );
}


PVal* CCall::CArgData::getThisPVal(void) const
{
	return getThis()->pval;
}


APTR CCall::CArgData::getThisAptr(void) const
{
	return getThis()->aptr;
}


//------------------------------------------------
// ������ PVal, APTR �𓾂�
//------------------------------------------------
PVal* CCall::CArgData::getArgPVal( int iArg ) const
{
	if ( !numrg(iArg, 0, mCntArg - 1) ) return NULL;
	return (*mpArgVal)[iArg];
}


APTR CCall::CArgData::getArgAptr( int iArg ) const
{
	if ( !numrg(iArg, 0, mCntArg - 1) ) return 0;
	
	APTR aptr = mpIdxRef->at(iArg);
	
	if ( aptr < 0 ) aptr = 0;
	
	return aptr;
}


//------------------------------------------------
// �����̏����擾����
//------------------------------------------------
int CCall::CArgData::getArgInfo( ARGINFOID id, int iArg ) const
{
	// �����Ȃ�A�Ăяo���S�̂ɑ΂�����𓾂�
	if ( iArg < 0 ) {
		return mCntArg;		// �����̐�
		
	} else {
		PVal* pval = (*mpArgVal)[iArg];
		switch ( id ) {
			case ARGINFOID_FLAG: return pval->flag;
			case ARGINFOID_MODE: return pval->mode;
			case ARGINFOID_LEN1: return pval->len[1];
			case ARGINFOID_LEN2: return pval->len[2];
			case ARGINFOID_LEN3: return pval->len[3];
			case ARGINFOID_LEN4: return pval->len[4];
			case ARGINFOID_SIZE: return pval->size;
			case ARGINFOID_PTR : 
			{
				HspVarProc* vp = exinfo->HspFunc_getproc( pval->flag );
				return reinterpret_cast<int>(
					vp->GetPtr(pval)
				);
			}
			case ARGINFOID_BYREF: return static_cast<int>( mpIdxRef->at(iArg) >= 0 );
			
			default:
				return 0;
		}
	}
}


//#########################################################
//        private�����o�֐��Q
//#########################################################
//------------------------------------------------
// ����
//------------------------------------------------
CCall::CArgData& CCall::CArgData::opCopy(const CCall::CArgData& obj)
{
	this->~CArgData();
	mpArgVal = new std::vector<PVal*>;
	mpIdxRef = new std::vector<APTR>;
	
	// CCall �|�C���^�̕���
	mpCall = obj.mpCall;
	
	// this �f�[�^�̕���
	setThis( obj.getThisPVal(), obj.getThisAptr() );
	
	// �������f�[�^�̕���
	mpArgVal->reserve( obj.getCntArg() );
	mpIdxRef->reserve( obj.getCntArg() );
	
	for ( int i = 0; i < obj.getCntArg(); ++ i ) {
		PVal* pval = obj.getArgPVal(i);
		APTR aptr  = obj.getArgAptr(i);
		
		// �l�n��
		if ( aptr < 0 ) {
			addArgByVal( pval );
			
		// �Q�Ɠn��
		} else {
			addArgByRef( pval );
		}
	}
	
	return *this;
}


//------------------------------------------------
// this �ϐ��̌�n��
//------------------------------------------------
void CCall::CArgData::clearThis(void)
{
	mvarThis.pval = NULL;
	mvarThis.aptr = 0;
	return;
}


//------------------------------------------------
// �������̉��
//------------------------------------------------
void CCall::CArgData::freeArgPVal(void)
{
	bool bPrminfo = mpCall->usesPrmInfo();
	
	// �����E�Ԓl�����ׂĉ������
	for ( int i = 0; i < mCntArg; i ++ )
	 {
		PVal* pArg = mpArgVal->at(i);
		
		// �l�n���̏ꍇ�APVal ���̕ϐ����������
		if ( mpIdxRef->at(i) < 0 ) {
			PVal_free( pArg );
		}
		
		if ( !bPrminfo ) {	// ���������Ȃ� => �N���[���Ȃ̂ō폜
			delete pArg;
		}
	}
	
	mpArgVal->clear();
	mpIdxRef->clear();
	delete mpArgVal; mpArgVal = NULL;
	delete mpIdxRef; mpIdxRef = NULL;
	
	return;
}


//#########################################################
//        �������֐��Q
//#########################################################



