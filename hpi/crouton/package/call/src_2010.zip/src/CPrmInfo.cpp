// ���������N���X

#include "mod_makepval.h"

#include "CPrmInfo.h"

//##############################################################################
//                ��`�� : CPrmInfo
//##############################################################################
//------------------------------------------------
// �W���\�z
//------------------------------------------------
CPrmInfo::CPrmInfo(label_t lb, const prmlist_t* pPrmlist, bool bFlex, bool bMethod)
	: mLabel  ( lb )
	, mcntPrms( 0 )
	, mbFlex  ( bFlex )
	, mbMethod( bMethod )
{
	if ( pPrmlist != NULL ) {
		// prmlist �̕���
		setPrmlist( *pPrmlist );
	}
	return;
}

//------------------------------------------------
// ���ʍ\�z
//------------------------------------------------
CPrmInfo::CPrmInfo( const CPrmInfo& obj )
{
	copy( obj );
}


//-----------------------------------------------
// ���
//-----------------------------------------------
// CPrmInfo::~CPrmInfo() { }


//###############################################
//    �ݒ�n
//###############################################
//-----------------------------------------------
// ���x��
//-----------------------------------------------
void CPrmInfo::setLabel( label_t lb )
{
	mLabel = lb;
	return;
}

//-----------------------------------------------
// �ϒ�������
//-----------------------------------------------
void CPrmInfo::setFlex( bool bFlex )
{
	mbFlex = bFlex;
	return;
}

//-----------------------------------------------
// ���\�b�h���ǂ���
//-----------------------------------------------
void CPrmInfo::set_isMethod( bool bMethod )
{
	mbMethod = bMethod;
	return;
}

//------------------------------------------------
// prmlist �̕���
//------------------------------------------------
void CPrmInfo::setPrmlist( const prmlist_t& prmlist )
{
	if ( prmlist.empty() ) return;
	
	mcntPrms = 0;
	mprmlist.clear();
	mprmlist.reserve( mcntPrms );
	
	for ( prmlist_t::const_iterator iter = prmlist.begin()
		; iter != prmlist.end()
		; iter ++
	) {
		if ( *iter == PRM_TYPE_FLEX ) {
			mbFlex = true;
			
		} else {
			mprmlist.push_back( *iter );
			mcntPrms ++;
		}
	}
	return;
}

//###############################################
//    �擾�n
//###############################################
//-----------------------------------------------
// ���x��
//-----------------------------------------------
label_t CPrmInfo::getLabel(void) const
{
	return mLabel;
}

//-----------------------------------------------
// �����̐�
//-----------------------------------------------
int CPrmInfo::cntPrms(void) const
{
	return mcntPrms;
}

//-----------------------------------------------
// �ϒ�������
//-----------------------------------------------
bool CPrmInfo::isFlex(void) const
{
	return mbFlex;
}

//-----------------------------------------------
// ���\�b�h���ǂ���
//-----------------------------------------------
bool CPrmInfo::isMethod(void) const
{
	return mbMethod;
}

//-----------------------------------------------
// �������^�C�v
// 
// @ index �͏z����B
// @ ���s����� PRM_TYPE_NONE ��Ԃ��B
//-----------------------------------------------
int CPrmInfo::getPrmType( int index ) const
{
	if ( index >= mcntPrms || index < 0 ) return PRM_TYPE_NONE;
	
	return mprmlist[index];
}

//-----------------------------------------------
// �������������ǂ������ׂ�
//-----------------------------------------------
void CPrmInfo::checkCorrectArg( const PVal* pvArg, int iArg, bool bByRef ) const
{
	int prmtype = getPrmType(iArg);
	
	// �ϒ�����
	if ( iArg >= cntPrms() ) {
		if ( isFlex() ) {
			// �K�����������Ƃɂ���
		} else {
			puterror( HSPERR_TOO_MANY_PARAMETERS );
		}
		
	// any
	} else if ( prmtype == PRM_TYPE_ANY ) {
		// OK
		
	// �Q�Ɠn���v��
	} else if ( prmtype == PRM_TYPE_VAR || prmtype == PRM_TYPE_ARRAY ) {
		if ( !bByRef ) {
			puterror( HSPERR_VARIABLE_REQUIRED );
		}
		
	// �^�s��v
	} else if ( prmtype != pvArg->flag ) {
		puterror( HSPERR_TYPE_MISMATCH );
	}
	
	return;
}

//-----------------------------------------------
// �ȗ��l���擾
// 
// @ �ȗ��ł��Ȃ��ꍇ�A����ɃG���[�ɂ���
//-----------------------------------------------
PVal*  CPrmInfo::getDefaultArg( int iArg ) const
{
	int prmtype = getPrmType(iArg);
	PVal* pval;
	
	// �ϒ�����
	if ( iArg >= cntPrms() ) {
		if ( isFlex() ) {
			pval = PVal_getDefault();
		} else {
			puterror( HSPERR_TOO_MANY_PARAMETERS );
		}
		
	// �ʏ퉼�����ŁA����l�̂���^
	} else if
		(  prmtype == HSPVAR_FLAG_STR
		|| prmtype == HSPVAR_FLAG_DOUBLE
		|| prmtype == HSPVAR_FLAG_INT
	) {
		pval = PVal_getDefault( prmtype );
		
	// any
	} else if ( prmtype == PRM_TYPE_ANY ) {
		pval = PVal_getDefault();
		
	// �Q�Ɠn���v��
	} else if ( prmtype == PRM_TYPE_VAR || prmtype == PRM_TYPE_ARRAY ) {
		puterror( HSPERR_VARIABLE_REQUIRED );
		
	// �ȗ��s��
	} else {
		// ���x���^�̏ꍇ
		if ( prmtype == HSPVAR_FLAG_LABEL ) {
			puterror( HSPERR_LABEL_REQUIRED );
			
		// ���W���[���ϐ��^�̏ꍇ
		} else if ( prmtype == HSPVAR_FLAG_STRUCT ) {
			puterror( HSPERR_STRUCT_REQUIRED );
			
		// ���̑�
		} else {
			puterror( HSPERR_NO_DEFAULT );
		}
	}
	
	return pval;
}

//###############################################
//    ���Z�q
//###############################################
//-----------------------------------------------
// ���ʑ��
//-----------------------------------------------
CPrmInfo& CPrmInfo::operator = ( const CPrmInfo& obj )
{
	return copy( obj );
}

//################################################
//    ���������o�֐�
//################################################
//------------------------------------------------
// ����
//------------------------------------------------
CPrmInfo& CPrmInfo::copy( const CPrmInfo& obj )
{
	mLabel    = obj.mLabel;
	mcntPrms  = obj.mcntPrms;
	mbFlex    = obj.mbFlex;
	mbMethod  = obj.mbMethod;
	setPrmlist( obj.mprmlist );
	return *this;
}

//##########################################################
//        ��`�� : ���̑�
//##########################################################


//------------------------------------------------
// �Q�Ɠn���v�����ǂ���
//------------------------------------------------
bool IsPrmtypeRef(int prmtype)
{
	return prmtype == PRM_TYPE_VAR
		|| prmtype == PRM_TYPE_ARRAY
		|| prmtype == PRM_TYPE_MODVAR
	;
}
