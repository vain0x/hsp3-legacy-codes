// �ϐ��֘A utility

#include "mod_varutil.h"
#include "mod_argGetter.h"

//##########################################################
//        HspVarProc �֌W
//##########################################################
//------------------------------------------------
// HspVarProc ���擾����
//------------------------------------------------
HspVarProc* GetHspVarProc(vartype_t vflag)
{
	return exinfo->HspFunc_getproc(vflag);
}

HspVarProc* GetHspVarProc(const char* pVtName)
{
	return exinfo->HspFunc_seekproc(pVtName);
}

//##########################################################
//        �ϐ����̎擾
//##########################################################
//------------------------------------------------
// �v�f�����擾����
//------------------------------------------------
int GetPValCntElem(const PVal* pval)
{
	int cnt = 1;
	
	for ( int i = 1; i < (4 + 1); ++ i ) {
		if ( pval->len[i] ) {
			cnt *= pval->len[i];
	//	} else {
	//		break;
		}
	}
	
	return cnt;
}

//------------------------------------------------
// pval->pt �̊m�ۂ��Ă���T�C�Y���擾����(bytes)
//------------------------------------------------
int GetPValSize(const PVal* pval)
{
	HspVarProc* vp = GetHspVarProc( pval->flag );
	
	if ( vp->basesize < 0 ) {
		return vp->GetSize( reinterpret_cast<PDAT*>( pval->pt ) );
	} else {
		return vp->basesize;
	}
}

//------------------------------------------------
// ���̃|�C���^�𓾂� ( GetPtr )
//------------------------------------------------
void* GetPValRealPtr(const PVal* pval)
{
	HspVarProc* vp = GetHspVarProc( pval->flag );
	return vp->GetPtr( const_cast<PVal*>( pval ) );
}

//##########################################################
//        �ϐ��̍쐬
//##########################################################
//------------------------------------------------
// pval �� dimtype ����
// 
// @ x(a), y(b), z(c) ... �ɂ��ꎟ���z��̘A���������B
// @ dim �I�p�@�B
//------------------------------------------------
int dimtypeEx(vartype_t vflag)
{
	PVal* pval;
	APTR  aptr;
	
	// �Ђ����烋�[�v����
	for( int i = 0; code_isNextArg(); ++ i ) {
		
		// �ϐ���PVal�|�C���^�Ɨv�f�����擾
		aptr = code_getva( &pval );
		if ( i == 0 && aptr <= 0 ) {	// �擪�ŁA���� () �Ȃ�
			// dimtype ����
			int idx[4];
			idx[0] = code_getdi(1);
			idx[1] = code_getdi(0);
			idx[2] = code_getdi(0);
			idx[3] = code_getdi(0);
			exinfo->HspFunc_dim( pval, vflag, 0, idx[0], idx[1], idx[2], idx[3] );
			break;
		}
		
		exinfo->HspFunc_dim( pval, vflag, 0, aptr, 0, 0, 0 );
	}
	
	return 0;
}

//##########################################################
//        APTR �֌W
//##########################################################
//------------------------------------------------
// �Y������ aptr �l���쐬����
//------------------------------------------------
APTR CreateAptrFromIndex(const PVal* pval, int idx[4])
{
	int multiple[4];
	
	multiple[0] = 1;
	
	// 1 ������ʂ��Z�o
	for ( int i = 1; i < 4; ++ i ) {
		multiple[i] = multiple[i - 1] * pval->len[i];
	}
	
	// �|�����킹�邾��
	return (
		idx[0] * multiple[0] +
		idx[1] * multiple[1] +
		idx[2] * multiple[2] +
		idx[3] * multiple[3]
	);
}

//------------------------------------------------
// aptr ����Y�������߂�
//------------------------------------------------
void GetIndexFromAptr(const PVal* pval, APTR aptr, int ret[4])
{
	APTR tmpAptr = aptr;
	
	for ( int i = 0; i < 4; ++ i ) ret[i] = 0;
	
	for ( int i = 0; i < pval->arraycnt; ++ i ) {
		if ( pval->len[i + 1] ) {
			ret[i] = tmpAptr %  pval->len[i + 1];
			         tmpAptr /= pval->len[i + 1];
			if ( tmpAptr == 0 ) break;
		}
	}
	return;
}
