// #module �֌W�̏���

#ifndef __MODULE_MODULE_DATA_H__
#define __MODULE_MODULE_DATA_H__

#include "hsp3plugin_custom.h"

//##############################################################################
//                �֐��錾
//##############################################################################

// ���[�U��`���߂ȂǂȂ�
extern void code_expandstruct(char *p, STRUCTDAT *st, int option);

#endif
