// �����擾���W���[��

#ifndef __MODULE_ARGUMENT_GETTER_H
#define __MODULE_ARGUMENT_GETTER_H

#include "hsp3plugin_custom.h"

//##############################################################################
//                �֐��錾
//##############################################################################
// �����̎擾
extern bool code_getva_ex(PVal** pval, APTR* aptr);
extern int  code_getds_ex(char** ppStr, const char* defstr = "");
extern int  code_getsi(char** ppStr);
extern int  code_getvartype(int defType = HSPVAR_FLAG_NONE);
extern label_t code_getdlb(label_t defLabel = NULL);
//extern label_t code_getlb2(void);

// �z��Y��
extern void code_checkarray(PVal* pval);
extern char* code_checkarray_obj( PVal* pval, int* mptype );

// ���̑�
extern bool code_isNextArg(void);
extern int  code_skipprm(void);

#endif
