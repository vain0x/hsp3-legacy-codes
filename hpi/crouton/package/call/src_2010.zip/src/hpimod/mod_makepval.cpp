// PVal �̓Ǝ��Ǘ�

#include <stdlib.h>
#include <string.h>

#include "mod_makepval.h"

//##########################################################
//    �錾
//##########################################################
static PVal* PVal_initDefault(vartype_t vt);

//##########################################################
//    �֐�
//##########################################################
//------------------------------------------------
// PVal�\���̂̏�����
// 
// @ (pval == NULL) => �������Ȃ��B
//------------------------------------------------
void PVal_init(PVal* pval, vartype_t vflag)
{
	if ( pval == NULL ) return;
	
	pval->flag = vflag;
	pval->mode = HSPVAR_MODE_NONE;
	PVal_alloc( pval );
	return;
}

//------------------------------------------------
// �L����PVal�\���̂ɂ���
// 
// @ (pval == NULL || vflag != �L�� ) => �������Ȃ��B
//------------------------------------------------
void PVal_alloc(PVal* pval, PVal* pval2, vartype_t vflag)
{
	if ( pval  == NULL ) return;
	if ( vflag <= HSPVAR_FLAG_NONE ) vflag = pval->flag;
	
	HspVarProc* vp = exinfo->HspFunc_getproc( vflag );
	
	// pt ���m�ۂ���Ă���ꍇ�A�������
	if ( pval->flag != HSPVAR_FLAG_NONE && pval->mode != HSPVAR_MODE_NONE ) {
		PVal_free( pval );
	}
	
	// �m�ۏ���
	memset( pval, 0x00, sizeof(PVal) );
	pval->flag = vflag;
	pval->mode = HSPVAR_MODE_NONE;
	vp->Alloc(pval, pval2);
	return;
}

//------------------------------------------------
// PVal�\���̂�����������
//------------------------------------------------
void PVal_clear(PVal* pval, vartype_t vflag)
{
	PVal_alloc( pval, NULL, vflag );
}

//------------------------------------------------
// PVal �\���̂̒��g���������
// 
// @ (pval == NULL) => �������Ȃ��B
//------------------------------------------------
void PVal_free(PVal* pval)
{
	if ( pval == NULL ) return;
	
	HspVarProc* vp = exinfo->HspFunc_getproc( pval->flag );
	vp->Free( pval );
	
	return;
}

//------------------------------------------------
// ����l��\�� PVal �\���̂�������
// @private
// @ vt �͕K���L���Ȓl (str �` int)�B
//------------------------------------------------
static PVal* PVal_initDefault(vartype_t vt)
{
	static PVal** stt_pDefPVal   = NULL;
	static int    stt_cntDefPVal = 0;
	
	// stt_pDefPVal �̊g��
	if ( stt_cntDefPVal <= vt ) {
		int cntNew   = vt + 1;
		
		if ( stt_pDefPVal == NULL ) {
			stt_pDefPVal = (PVal** )hspmalloc( cntNew * sizeof(PVal* ) );
			
		} else {
			stt_pDefPVal = (PVal** )hspexpand(
				reinterpret_cast<char*>( stt_pDefPVal ),
				cntNew * sizeof(PVal* )
			);
		}
		
		// �g������ NULL �ŏ���������
		for( int i = stt_cntDefPVal; i < cntNew; ++ i ) {
			stt_pDefPVal[i] = NULL;
		}
		
		stt_cntDefPVal = cntNew;
	}
	
	// ���������̏ꍇ�́APVal �̃��������m�ۂ��A����������
	if ( stt_pDefPVal[vt] == NULL ) {
		stt_pDefPVal[vt] = (PVal* )hspmalloc( sizeof(PVal) );
		PVal_init( stt_pDefPVal[vt], vt );
	}
	return stt_pDefPVal[vt];
}


//------------------------------------------------
// ����l��\�� PVal �\���̂ւ̃|�C���^�𓾂�
// 
// @ vt ���s���ȏꍇ�ANULL ��Ԃ��B
//------------------------------------------------
PVal* PVal_getDefault( vartype_t vt )
{
	if ( vt <= HSPVAR_FLAG_NONE ) {
		return NULL;
		
	} else {
		return PVal_initDefault( vt );
	}
}

//##########################################################
//        �ϐ����̎擾
//##########################################################
//------------------------------------------------
// �ϐ��̗v�f���̑�����Ԃ�
//------------------------------------------------
int PVal_cntElems( PVal* pval )
{
	int cntElems = 1;
	
	// �v�f���𒲂ׂ�
	for ( unsigned int i = 0; i < ArrayDimCnt; ++ i ) {
		if ( pval->len[i + 1] ) {
			cntElems *= pval->len[i + 1];
		}
	}
	
	return cntElems;
}

//##########################################################
//        �ϐ��ɑ΂��鑀��
//##########################################################
//------------------------------------------------
// PVal�֒l���i�[���� (�ėp)
//------------------------------------------------
void PVal_assign(PVal* pval, void* pData, vartype_t vflag)
{
	HspVarProc* vp = exinfo->HspFunc_getproc(vflag);
	
	// �\�Ȃ� ObjectWrite
	if ( (vp->support & HSPVAR_SUPPORT_NOCONVERT) && vp->ObjectWrite ) {
		vp->ObjectWrite( pval, pData, vflag );
		
	// �ʏ�̑��
	} else if ( vp->Set ) {
		code_setva( pval, pval->offset, vflag, pData );
		
	// �G���[
	} else {
		puterror( HSPERR_UNSUPPORTED_FUNCTION );
	}
	return;
}

//------------------------------------------------
// PVal�̕���
//------------------------------------------------
void PVal_copy(PVal* pvDst, PVal* pvSrc)
{
	if ( pvDst == pvSrc ) return;
	
	int cntElems = PVal_cntElems(pvSrc);
	
	// pvDst ���m�ۂ���
	exinfo->HspFunc_dim(
		pvDst, pvSrc->flag, 0, pvSrc->len[1], pvSrc->len[2], pvSrc->len[3], pvSrc->len[4]
	);
	
	// �A���������
	HspVarProc* pHvpSrc = exinfo->HspFunc_getproc( pvSrc->flag );
	
	for ( int i = 0; i < cntElems; ++ i ) {
		pvDst->offset = i;
		pvSrc->offset = i;
		
		PVal_assign( pvDst, pHvpSrc->GetPtr( pvSrc ), pvSrc->flag );
	}
	return;
}

//------------------------------------------------
// �ϐ����N���[���ɂ���
//------------------------------------------------
void PVal_dup(PVal* pvDst, PVal* pvSrc, APTR aptrSrc)
{
	HspVarCoreDup( pvDst, pvSrc, aptrSrc );
}

void PVal_dup(PVal* pvDst, void* ptr, int flag, int size)
{
	HspVarCoreDupPtr( pvDst, flag, ptr, size );
}

//------------------------------------------------
// �l���V�X�e���ϐ��ɃZ�b�g����
//------------------------------------------------
void SetResultSysvar(const void* pValue, vartype_t vflag)
{
	if ( pValue == NULL ) return;
	
	ctx->retval_level = ctx->sublev;
	
	switch ( vflag )
	 {
		case HSPVAR_FLAG_INT:
			ctx->stat = *reinterpret_cast<const int*>( pValue );
			break;
			
		case HSPVAR_FLAG_STR:
			strncpy(
				ctx->refstr,
				reinterpret_cast<const char*>( pValue ),
				HSPCTX_REFSTR_MAX - 1
			);
			break;
			
		case HSPVAR_FLAG_DOUBLE:
			ctx->refdval = *reinterpret_cast<const double* >( pValue );
			break;
			
		default:
			puterror( HSPERR_TYPE_MISMATCH );
	}
	return;
}


//#########################################################
//        OpenHSP����̈��p
//#########################################################
// ������ł���悤�ɁA�኱�ύX���Ă��܂�

//------------------------------------------------
// �w�肳�ꂽ�|�C���^����̃N���[���ɂȂ�
//------------------------------------------------
void HspVarCoreDupPtr( PVal* pval, int flag, void* ptr, int size )
{
	PDAT* buf;
	HspVarProc* p;
	p   = exinfo->HspFunc_getproc(flag);	//@ p = &hspvarproc[ flag ];
	buf = (PDAT* )ptr;
	
	p->Free( pval );			//@ HspVarCoreDispose(pval);
	pval->pt = (char* )buf;
	pval->flag = flag;
	pval->size = size;
	pval->mode = HSPVAR_MODE_CLONE;
	pval->len[0] = 1;
	
	if ( p->basesize < 0 ) {
		pval->len[1] = 1;
	} else {
		pval->len[1] = size / p->basesize;
	}
	pval->len[2] = 0;
	pval->len[3] = 0;
	pval->len[4] = 0;
	pval->offset = 0;
	pval->arraycnt = 0;
	pval->support = HSPVAR_SUPPORT_STORAGE;
	return;
}


//------------------------------------------------
// �w�肳�ꂽ�ϐ��̃N���[���ɂȂ�
//------------------------------------------------
void HspVarCoreDup( PVal* pval, PVal* arg, APTR aptr )
{
	if ( aptr < 0 ) aptr = arg->offset;
	int size;
	PDAT* buf;
	HspVarProc* p;
	p = exinfo->HspFunc_getproc(arg->flag);		//@ p = &hspvarproc[ arg->flag ];
	arg->offset = aptr;							//@ buf = HspVarCorePtrAPTR( arg, aptr );
	buf = p->GetPtr(arg);						//@ �V
	p->GetBlockSize(arg, buf, &size);			//@ HspVarCoreGetBlockSize( arg, buf, &size );
	HspVarCoreDupPtr( pval, arg->flag, buf, size );
	return;
}
