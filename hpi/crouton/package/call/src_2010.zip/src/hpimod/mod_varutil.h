// �ϐ��֘A utility

#ifndef __MODULE_VARIABLE_UTILITY_H
#define __MODULE_VARIABLE_UTILITY_H

#include "hsp3plugin_custom.h"

//##########################################################
//        �֐��錾
//##########################################################
// HspVarProc �̎擾
extern HspVarProc* GetHspVarProc(vartype_t vflag);
extern HspVarProc* GetHspVarProc(const char* pVtName);

// �ϐ����̎擾
extern int   GetPValCntElem(const PVal* pval);
extern int   GetPValSize   (const PVal* pval);
extern void* GetPValRealPtr(const PVal* pval);

// �ϐ��̍쐬
extern int dimtypeEx(vartype_t vt);

// APTR �֌W
extern APTR CreateAptrFromIndex(const PVal* pval, int idx[4]);
extern void GetIndexFromAptr   (const PVal* pval, APTR aptr, int ret[4]);

#endif
