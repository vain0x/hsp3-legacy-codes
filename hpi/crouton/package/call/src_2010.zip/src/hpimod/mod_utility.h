// ������

#ifndef IG_MODULE_HPIMOD_UTILITY_H
#define IG_MODULE_HPIMOD_UTILITY_H

#include "hsp3plugin_custom.h"

//##########################################################
//        �֐��錾
//##########################################################

extern label_t    GetLabel_fromOTindex(int otindex);

#endif
