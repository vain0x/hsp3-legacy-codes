// vartype - caller

#include "hsp3plugin_custom.h"

#include "vt_caller.h"
#include "cmd_call.h"
#include "cmd_sub.h"

#include "CCaller.h"
#include "defid.h"

// �ϐ��̐錾
vartype_t HSPVAR_FLAG_CALLER;
static HspVarProc* g_pHvpCaller;

// �֐��錾 ( ���ׂĎ�������Ă����ł͂Ȃ� )
static int   HspVarCaller_calcVarSize(const PVal* pval);
static void* HspVarCaller_cnv      (const void* buffer, int flag);
static void* HspVarCaller_cnvCustom(const void* buffer, int flag);
static PDAT* HspVarCaller_getptr    (PVal* pval);
static int   HspVarCaller_getVarSize(PVal* pval);
static void* HspVarCaller_arrayObjectRead(PVal* pval, int* mptype);
static void  HspVarCaller_arrayObject(PVal* pval);
static void  HspVarCaller_objectWrite(PVal* pval, void* data, int vflag);
static void  HspVarCaller_method     (PVal* pval);
static void  HspVarCaller_alloc(PVal* pval, const PVal* pval2);
static void  HspVarCaller_free (PVal* pval);
static int   HspVarCaller_getSize (const PDAT* pdat);
static int   HspVarCaller_getUsing(const PDAT* pdat);
static void* HspVarCaller_getBlockSize(PVal* pval, PDAT* pdat, int* size);
static void  HspVarCaller_allocBlock  (PVal* pval, PDAT* pdat, int  size);
static void  HspVarCaller_set(PVal* pval, PDAT* pdat, const void* in);
static void  HspVarCaller_addI (PDAT* pdat, const void* val);
static void  HspVarCaller_subI (PDAT* pdat, const void* val);
static void  HspVarCaller_mulI (PDAT* pdat, const void* val);
static void  HspVarCaller_divI (PDAT* pdat, const void* val);
static void  HspVarCaller_modI (PDAT* pdat, const void* val);
static void  HspVarCaller_andI (PDAT* pdat, const void* val);
static void  HspVarCaller_orI  (PDAT* pdat, const void* val);
static void  HspVarCaller_xorI (PDAT* pdat, const void* val);
static void  HspVarCaller_eqI  (PDAT* pdat, const void* val);
static void  HspVarCaller_neI  (PDAT* pdat, const void* val);
static void  HspVarCaller_gtI  (PDAT* pdat, const void* val);
static void  HspVarCaller_ltI  (PDAT* pdat, const void* val);
static void  HspVarCaller_gtEqI(PDAT* pdat, const void* val);
static void  HspVarCaller_ltEqI(PDAT* pdat, const void* val);
static void  HspVarCaller_rrI  (PDAT* pdat, const void* val);
static void  HspVarCaller_lrI  (PDAT* pdat, const void* val);

// �T�|�[�g�֐�
static StCaller* GetCallerPtr(const PVal* pval);
static StCaller* GetCallerPtr(const PDAT* pdat);
static void Call_callerVar(PVal* pval, CCaller &caller);
static void Call_callerVar(StCaller* pstCaller, CCaller &caller);

//------------------------------------------------
// PVal::pt ���K�v�Ƃ���T�C�Y(byte)���擾����
// 
// @ PVal::size �ɐݒ肳���
//------------------------------------------------
static int HspVarCaller_calcVarSize(const PVal* pval)
{
/*
	return GetPValCntElem(pval) * sizeof(StCaller);
/*/
	int count = pval->len[1];
	if ( pval->len[2] ) count *= pval->len[2];
	if ( pval->len[3] ) count *= pval->len[3];
	if ( pval->len[4] ) count *= pval->len[4];
	return count * sizeof(StCaller);
//*/
}

//------------------------------------------------
// �^�ϊ�����
// 
// @ �� -> caller
//------------------------------------------------
static void* HspVarCaller_cnv(const void* buffer, int flag)
{
	static StCaller stt_cnv;
	
	switch ( flag ) {
		case HSPVAR_FLAG_LABEL:
			stt_cnv.dest.type = DestType_Label;
			stt_cnv.dest.lb   = *(label_t*)buffer;
			break;
			
		case HSPVAR_FLAG_INT:
		{
			stt_cnv.dest.type   = DestType_Deffid;
			stt_cnv.dest.deffid = *(int*)buffer;
			
			// MODCMD ���`�F�b�N����
			if ( !isModcmdId( stt_cnv.dest.deffid ) ) puterror( HSPERR_ILLEGAL_FUNCTION );
			break;
		}
		default:
			if ( flag == HSPVAR_FLAG_CALLER ) {
				stt_cnv = *(StCaller*)buffer;
				
			} else {
				puterror( HSPERR_TYPE_MISMATCH );
			}
			break;
	}
	
	return &stt_cnv;
}

//------------------------------------------------
// �^�ϊ�����
// 
// @ caller -> ��
//------------------------------------------------
static void* HspVarCaller_cnvCustom(const void* buffer, int flag)
{
	StCaller* pstCaller = (StCaller*)buffer;
	
	switch ( flag ) {
		case HSPVAR_FLAG_LABEL:
		{
			static label_t stt_label;
			
			if ( pstCaller->dest.type == DestType_Label ) {
				stt_label = pstCaller->dest.lb;
				return &stt_label;
			}
			break;
		}
		case HSPVAR_FLAG_INT:
		{
			static int stt_int;
			
			if ( pstCaller->dest.type == DestType_Deffid ) {
				stt_int = pstCaller->dest.deffid;
				return &stt_int;
			}
			break;
		}
		
		default:
			break;
	}
	
	puterror( HSPERR_TYPE_MISMATCH );
	
	// �����ɂ͗��Ȃ� (�x���}��)
	throw HSPERR_TYPE_MISMATCH;
}

//------------------------------------------------
// ���̃|�C���^�𓾂�
// 
// @ �z�񖢑Ή��Ȃ̂� offset �͖�������
//------------------------------------------------
static PDAT* HspVarCaller_getptr(PVal* pval)
{
	return (PDAT*)(&pval->pt[pval->offset]);
}

//------------------------------------------------
// PVal�̕ϐ����������m�ۂ���
// 
// @! pval �͂��łɉ���ς� (or ���m��)�B
// @! pval2 �� NULL �̏ꍇ�́A���ʂɊm�ۂ���B
// @! pval2 ���w�肳��Ă���ꍇ�́Apval2�̓��e���p������
//------------------------------------------------
static void HspVarCaller_alloc(PVal* pval, const PVal* pval2)
{
	int size;
	char* pt;
	
	if ( pval->len[1] < 1 ) pval->len[1] = 1;		// �z����Œ� 1 �͊m�ۂ���
	size       = HspVarCaller_calcVarSize(pval);	// '\0' ���̃T�C�Y���m�ۂ��Ă���
	pval->flag = HSPVAR_FLAG_CALLER;
	pval->mode = HSPVAR_MODE_MALLOC;
	pt         = hspmalloc(size);
	
	// �}�X�^�[�̊m��
	{
		StCallerMaster* pMaster = reinterpret_cast<StCallerMaster*>(
			hspmalloc( sizeof(StCallerMaster) )
		);
		
		pMaster->vtResult = HSPVAR_FLAG_NONE;
		pMaster->pResult  = NULL;
		
		pval->master = pMaster;
	}
	
	// StCaller[] �̏�����
	memset( pt, 0, size );
	{
		StCaller stCaller;
		stCaller.dest.type = DestType_None;
		stCaller.dest.lb   = NULL;
		
		// �z��܂邲�Ə����� ( �s�v��������Ȃ��� )
		for ( unsigned int i = 0; i < (size / sizeof(StCaller)); ++ i ) {
			((StCaller*)pt)[i] = stCaller;
		}
	}
	
	// �p������
	if ( pval2 != NULL ) {
		memcpy( pt, pval2->pt, pval2->size );	// �����Ă����f�[�^���R�s�[
		hspfree( pval2->pt );					// ���̃o�b�t�@�����
	}
	pval->pt   = pt;
	pval->size = size;
	return;
}

//------------------------------------------------
// PVal�̕ϐ����������������
//------------------------------------------------
static void HspVarCaller_free(PVal* pval)
{
	if ( pval->mode == HSPVAR_MODE_MALLOC ) {
		hspfree(pval->pt);
	}
	pval->pt   = NULL;
	pval->mode = HSPVAR_MODE_NONE;
	return;
}

//------------------------------------------------
// �v�f���m�ۂ��Ă���T�C�Y���擾
//------------------------------------------------
static int HspVarCaller_getSize(const PDAT* pdat)
{
	return sizeof(StCaller);
}

//------------------------------------------------
// �g�p��(varuse)
//------------------------------------------------
static int HspVarCaller_getUsing( const PDAT* pdat )
{
	StCaller* pstCaller = GetCallerPtr( pdat );
	DestType desttype   = pstCaller->dest.type;
	
	return !( desttype == DestType_None
		||  ( desttype == DestType_Label  &&  pstCaller->dest.lb == NULL )
		||  ( desttype == DestType_Deffid && !isModcmdId(pstCaller->dest.deffid) )
	);
}

//------------------------------------------------
// �u���b�N�T�C�Y���擾
//------------------------------------------------
static void* HspVarCaller_getBlockSize(PVal* pval, PDAT* pdat, int* size)
{
	*size = pval->size - ( (char*)pdat - (char*)pval->pt );
	return (pdat);
}

//------------------------------------------------
// �ϒ��̂���
//------------------------------------------------
static void HspVarCaller_allocBlock(PVal* pval, PDAT* pdat, int size)
{
	return;
}

/*
//------------------------------------------------
// �A�z�z�� : �ǂݍ���
//------------------------------------------------
static void* HspVarCaller_arrayObjectRead(PVal* pval, int* mptype)
{
	g_pHvpCaller->ArrayObject( pval );
	
	StCallerMaster *pMaster = reinterpret_cast<StCallerMaster *>( pval->master );
	
	if ( pMaster->vtResult == HSPVAR_FLAG_NONE || pMaster->pResult == NULL ) {
		puterror( HSPERR_NORETVAL );
	}
	
	*mptype = pMaster->vtResult;
	return pMaster->pResult;
}
//*/

/*
//------------------------------------------------
// �A�z�z�� : �z��Q��
// 
// @ �Q�Ɠn���̂Ƃ��ɍ���̂ŁA�p���B
//------------------------------------------------
static void HspVarCaller_arrayObject(PVal* pval)
{
	StCaller* pstCaller = GetCallerPtr( pval );
	
	if ( pstCaller->dest.type == DestType_None ) {
		return;
	}
	
	// �Ăяo��
	{
		CCaller caller;
		
		Call_callerVar( pstCaller, caller );
		
		// �Ԓl���󂯎�� ( �Ȃ��Ă��悢 )
		StCallerMaster *pMaster = reinterpret_cast<StCallerMaster *>( pval->master );
		
		pMaster->vtResult = caller.getCallResult( &pMaster->pResult );
	}
	
	return;
}
//*/

/*
//------------------------------------------------
// �^�ϊ��Ȃ��̊i�[
//------------------------------------------------
static void HspVarCaller_objectWrite(PVal* pval, void* data, int vflag)
{
	StCaller* pstCaller = GetCallerPtr( pval );
	
	*pstCaller = *(StCaller* )g_pHvpCaller->Cnv(data, vflag);
	
	return;
}
//*/

//------------------------------------------------
// ���\�b�h����
//------------------------------------------------
static void HspVarCaller_method(PVal* pval)
{
	char* psMethod = code_gets();
	
	if ( !strcmp(psMethod, "call") ) {
		CCaller caller;
		
		Call_callerVar( pval, caller );
		
	} else {
		puterror( HSPERR_INVALID_PARAMETER );
	}
	return;
}

//*
//------------------------------------------------
// ����֐�
//------------------------------------------------
static void  HspVarCaller_set(PVal* pval, PDAT* pdat, const void* in)
{
	StCaller* pstCaller = GetCallerPtr( pval );
	
	*pstCaller = *(StCaller*)in;
	return;
}
//*/

//------------------------------------------------
// ��r�֐�
//------------------------------------------------
static void HspVarCaller_eqI(PDAT* pdat, const void* val)
{
	StCaller* pstCaller[2] = {
		((StCaller*)pdat), 
		((StCaller*)val)
	};
	
	bool bEq = (
			pstCaller[0]->dest.type == pstCaller[1]->dest.type
		&&	pstCaller[0]->dest.lb   == pstCaller[1]->dest.lb
	);
	
	*((int*)pdat)           = bEq ? 1 : 0;
	g_pHvpCaller->aftertype = HSPVAR_FLAG_INT;
	return;
}

// !=
static void HspVarCaller_neI(PDAT* pdat, const void* val)
{
	HspVarCaller_eqI(pdat, val);
	
	*((int*)pdat) ^= 1;
	return;
}

//------------------------------------------------
// HspVarProc�������֐�
//------------------------------------------------
void HspVarCaller_init(HspVarProc* p)
{
	HSPVAR_FLAG_CALLER = p->flag;
	g_pHvpCaller       = p;
	
	p->Cnv          = HspVarCaller_cnv;
	p->CnvCustom    = HspVarCaller_cnvCustom;
	p->GetPtr       = HspVarCaller_getptr;
	
	p->Alloc        = HspVarCaller_alloc;
	p->Free         = HspVarCaller_free;
	
	p->GetSize      = HspVarCaller_getSize;
	p->GetUsing     = HspVarCaller_getUsing;
	
	p->GetBlockSize = HspVarCaller_getBlockSize;
	p->AllocBlock   = HspVarCaller_allocBlock;
	
//	p->ArrayObjectRead = HspVarCaller_arrayObjectRead;
//	p->ArrayObject  = HspVarCaller_arrayObject;
//	p->ObjectWrite  = HspVarCaller_objectWrite;
	p->ObjectMethod = HspVarCaller_method;
	
	p->Set          = HspVarCaller_set;
	
//	p->AddI         = HspVarCaller_addI;
//	p->SubI         = HspVarCaller_subI;
//	p->MulI         = HspVarCaller_mulI;
//	p->DivI         = HspVarCaller_divI;
//	p->ModI         = HspVarCaller_modI;
	
//	p->AndI         = HspVarCaller_andI;
//	p->OrI          = HspVarCaller_orI;
//	p->XorI         = HspVarCaller_xorI;
	
	p->EqI          = HspVarCaller_eqI;
	p->NeI          = HspVarCaller_neI;
//	p->GtI          = HspVarCaller_gtI;
//	p->LtI          = HspVarCaller_ltI;
//	p->GtEqI        = HspVarCaller_gtEqI;
//	p->LtEqI        = HspVarCaller_ltEqI;
	
//	p->RrI          = HspVarCaller_rrI;
//	p->LrI          = HspVarCaller_lrI;
	
	p->vartype_name	= "caller";	// �^��
	p->version      = 0x001;	// VarType RuntimeVersion(0x100 = 1.0)
	p->support      = HSPVAR_SUPPORT_STORAGE
					| HSPVAR_SUPPORT_FLEXARRAY
	//				| HSPVAR_SUPPORT_ARRAYOBJ
					| HSPVAR_SUPPORT_NOCONVERT
	                | HSPVAR_SUPPORT_VARUSE
					;						// �T�|�[�g�󋵃t���O(HSPVAR_SUPPORT_*)
	p->basesize     = sizeof(StCaller);		// 1�̃f�[�^��bytes / �ϒ��̎���-1
	return;
}

//##############################################################################
//                �������֐�
//##############################################################################
//------------------------------------------------
// PVal, PDAT ���� StCaller �|�C���^�𓾂�
// 
// @ �^�s���S
// @ �L���X�g����
//------------------------------------------------
static StCaller* GetCallerPtr(const PVal* pval)
{
	if ( pval->flag != HSPVAR_FLAG_CALLER ) {
		return NULL;
	} else {
		return (StCaller*)g_pHvpCaller->GetPtr( const_cast<PVal*>(pval) );
	}
}

static StCaller* GetCallerPtr(const PDAT* pdat)
{
	return (StCaller*)pdat;
}

//------------------------------------------------
// caller �I�u�W�F�N�g�� call ����
// 
// @ �������͒��ԃR�[�h������o��
//------------------------------------------------
static void Call_callerVar(PVal* pval, CCaller &caller)
{
	Call_callerVar( GetCallerPtr(pval), caller );
	return;
}

static void Call_callerVar(StCaller* pstCaller, CCaller &caller)
{
	switch ( pstCaller->dest.type ) {
		case DestType_None:
			puterror( HSPERR_LABEL_REQUIRED );
			break;
			
		case DestType_Label:
			caller.setJumpDest( pstCaller->dest.lb );
			break;
			
		case DestType_Deffid:
		{
			STRUCTDAT* pStDat = GetSTRUCTDAT( pstCaller->dest.deffid );
			caller.setJumpDest( *pStDat );
			break;
		}
	}
	
	caller.setArgAll();
	caller.call();
	
	return;
}
