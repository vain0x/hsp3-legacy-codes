// call - main.h

#ifndef IG_CALL_MAIN_H
#define IG_CALL_MAIN_H

#define WIN32_LEAN_AND_MEAN		// <commdlg.h> �� include ���Ȃ�
#include <windows.h>

//#include <cstdio>
//#include <cstdlib>
//#include <cstring>

//#include "strbuf.h"
#include "hsp3plugin_custom.h"

extern int g_pluginType_call;

namespace CallCmdId
{
	const int
		ByRef = 0x210
	;
};

#endif
