// DefId

#ifndef IG_DEF_ID_H
#define IG_DEF_ID_H

namespace DefId
{

static const int MagicCode = 0x20000000;

inline int make( int type, int code )
{
	return ( MagicCode | ((type & 0x0FFF) << 16) | (code & 0xFFFF) );
}

inline int getType( int id )
{
	return ( (id & MagicCode) ? ((id >> 16) & 0x0FFF) : 0 );
}

inline int getCode( int id )
{
	return ( (id & MagicCode) ? (id & 0xFFFF) : 0 );
}

};

#endif
