// Call(Method) - Command header

#ifndef IG_CALL_METHOD_COMMAND_H
#define IG_CALL_METHOD_COMMAND_H

#include <windows.h>
#include "hsp3plugin.h"

extern void Method_replace(void);
extern void Method_add(void);
extern void Method_cloneThis(void);

#endif
