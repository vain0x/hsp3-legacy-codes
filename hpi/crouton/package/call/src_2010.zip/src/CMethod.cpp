// ���\�b�h�Ǘ��N���X

#include <windows.h>
#include "hsp3plugin.h"

#include <map>
#include <string>

#include "CCaller.h"
#include "CMethod.h"

#include "cmd_sub.h"

//------------------------------------------------
// �\�z
//------------------------------------------------
CMethod::CMethod(vartype_t vt)
	: mVartype( vt )
	, mpMethodlist( new methodlist_t )
{ }


//------------------------------------------------
// ���
//------------------------------------------------
CMethod::~CMethod()
{
	delete [] mpMethodlist; mpMethodlist = NULL;
	return;
}


//--------------------------------------------
// ���\�b�h��ǉ�
//--------------------------------------------
void CMethod::add(const std::string& name, const CPrmInfo& prminfo)
{
	mpMethodlist->insert(
		std::pair<std::string, CPrmInfo>( name, prminfo )
	);
	return;
}


//--------------------------------------------
// ���\�b�h���Ăяo��
// @ ���ߌ`��
//--------------------------------------------
void CMethod::call(const std::string& name, PVal* pvThis)
{
	if ( mpMethodlist->count(name) == 0 ) puterror( HSPERR_UNSUPPORTED_FUNCTION );
	
	std::map<std::string, CPrmInfo>::iterator
		iter = mpMethodlist->find( name );
	
	// �Ăяo��
	{
		CCaller caller;
		CPrmInfo* pPrmInfo = &iter->second;
		CCall    *pCall    = caller.getCall();
		
		pCall->setPrmInfo( pPrmInfo );
		pCall->setThis( pvThis, pvThis->offset );
		
		caller.setArgAll();	// �����̐ݒ�
		caller.call();		// �Ăяo��
	}
	
	return;
}
