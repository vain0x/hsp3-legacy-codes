// vartype - caller

#ifndef IG_VARTYPE_CALLER_H
#define IG_VARTYPE_CALLER_H

#include "hsp3plugin_custom.h"
#include "StDest.h"

extern vartype_t HSPVAR_FLAG_CALLER;
extern void HspVarCaller_init(HspVarProc* vp);

// PVal::pt �ɔz���ɊǗ������\����
struct StCaller
{
	StDest dest;
};

// PVal::master �̍\����
struct StCallerMaster
{
	vartype_t vtResult;
	void* pResult;
};

#endif
