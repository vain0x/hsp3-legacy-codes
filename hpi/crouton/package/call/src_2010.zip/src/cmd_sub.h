// Call - SubCommand header

#ifndef IG_CALL_SUB_COMMAND_H
#define IG_CALL_SUB_COMMAND_H

#include "hsp3plugin_custom.h"
#include "mod_argGetter.h"
#include "mod_makepval.h"

#include "CCall.h"
#include "StDest.h"
#include "cmd_call.h"

//################################################
//    Call �������֐�
//################################################
// �֐��Ԓl
extern int   SetCallResult(void** ppResult);
extern PVal* GetCallRetVal(void);

// �Ǝ��X�^�b�N
extern void  PushCallStack(CCall* pCall);
extern void   PopCallStack(void);
extern void  FreeCallStack(void);
extern CCall* TopCallStack(void);

// ���������X�g
extern void  DeclarePrmInfo(const CPrmInfo& prminfo);
extern CPrmInfo* GetPrmInfo(label_t lb);

// �ϊ��֐�
extern void CreatePrmInfo(CPrmInfo* pPrmInfo);
extern void CreatePrmInfo(CPrmInfo* pPrmInfo, const STRUCTDAT* pStDat);
extern void CreatePrmStack(CPrmStk* pPrmStack, const CCall* pCall);

// ���̑�
extern label_t    GetLabel(StDest& rDest);
extern STRUCTDAT* GetSTRUCTDAT(int deffid);
extern int GetPrmType(const char* s);

//################################################
//    �������֐�
//################################################
extern bool numrg(int val, int min, int max);

// �����擾
extern int code_getprmtype(int deftype = PRM_TYPE_NONE);
extern void code_getdest(StDest& dest);
extern int code_getdefid(void);

#endif
