/******************************************************************************
*
*		Call hpi
*				author Ue-dai @2008 11/2(Sun)
*
******************************************************************************/

#include "dllmain.h"
#include "cmd_call.h"
#include "cmd_method.h"
#include "vt_caller.h"

#include "mod_varutil.h"

// �ϐ��錾
extern int g_pluginType_call = -1;

// �֐��錾
extern int   ProcFunc( int cmd, void** ppResult );
extern int ProcSysvar( int cmd, void** ppResult );

//###############################################
//        ���߃R�}���h�Ăяo���֐�
//###############################################
static int cmdfunc( int cmd )
{
	code_next();
	
	switch( cmd ) {
		case 0x000: Call();             break;	// call
		case 0x001: Call_alias();       break;	// call_alias
		case 0x002: Call_aliasAll();    break;	// call_aliasAll
		case 0x003: Call_retval();      break;	// call_retval
		case 0x004: Call_declare();     break;	// call_dec
		
		case 0x010: Call_StreamBegin(); break;	// call_stream_begin
		case 0x011: Call_StreamLabel(); break;	// call_stream_label
		case 0x012: Call_StreamAdd();   break;	// call_stream_add
		case 0x013: Call_StreamEnd();   break;	// call_stream_end
		
		case 0x020: Method_replace();   break;	// method_replace
		case 0x021: Method_add();       break;	// method_add
//		case 0x022: Method_cloneThis(); break;	// method_cloneThis
		
		case 0x030: dimtypeEx( HSPVAR_FLAG_CALLER ); break;
		
		case 0x040: CallCmd_sttm();     break;	// callcs
		
#ifdef _DEBUG
		case 0x0FF: CallHpi_test(); break;
#endif
		default:
			puterror( HSPERR_UNSUPPORTED_FUNCTION );
	}
	return RUNMODE_RUN;
}


//###############################################
//        �֐��R�}���h�Ăяo���֐�
//###############################################
static void* reffunc( int* type_res, int cmd )
{
	void* pResult = NULL;
	
	// '('�Ŏn�܂邩�𒲂ׂ� : �n�܂�Ȃ���΃V�X�e���ϐ�
	if ( *type != TYPE_MARK || *val != '(' ) {
		
		*type_res = ProcSysvar( cmd, &pResult );
		
	} else {
		
		code_next();
		
		// �R�}���h����
		*type_res = ProcFunc( cmd, &pResult );
		
		// '('�ŏI��邩�𒲂ׂ�
		if ( *type != TYPE_MARK || *val != ')' ) puterror( HSPERR_INVALID_FUNCPARAM );
		code_next();
		
	}
	
	if ( pResult == NULL ) puterror( HSPERR_NORETVAL );
	
	return pResult;
}


//###############################################
//        �֐��R�}���h�����֐�
//###############################################
static int ProcFunc( int cmd, void** ppResult )
{
	switch ( cmd ) {
		case 0x000:	return Call          (ppResult);	// call()
		case 0x013: return Call_StreamEnd(ppResult);	// call_stream()
		case 0x030: return Caller_cnv    (ppResult);	// caller()
		case 0x040: return CallCmd_func  (ppResult);	// callcf()
		
		case 0x100: return Call_arginfo  (ppResult);	// call_arginfo()
		case 0x101: return Call_argv     (ppResult);	// call_argv()
		case 0x102: return Call_result   (ppResult);	// call_result()
		case 0x103: return DefIdOf       (ppResult);	// defidOf()
		case 0x104: return LabelOf       (ppResult);	// labelOf()
		
		default:
			puterror( HSPERR_UNSUPPORTED_FUNCTION );
	}
	return 0;
}


//###############################################
//        �V�X�e���ϐ��R�}���h�����֐�
//###############################################
static int ProcSysvar( int cmd, void** ppResult )
{
	switch ( cmd ) {
		case 0x030: return SetReffuncResult( ppResult, HSPVAR_FLAG_CALLER );
		
		case 0x200:	return Call_thislb( ppResult );	// call_thislb
			
		case CallCmdId::ByRef: //
		default:
			puterror( HSPERR_UNSUPPORTED_FUNCTION );
	}
	return 0;
}


//###############################################
//        �I�����Ăяo���֐�
//###############################################
static int termfunc( int option )
{
	return 0;
}


//###############################################
//        �v���O�C���������֐�
//###############################################
EXPORT void WINAPI hsp3hpi_init( HSP3TYPEINFO* info )
{
	g_pluginType_call = info->type;
	
	hsp3sdk_init( info );			// SDK�̏�����(�ŏ��ɍs�Ȃ��ĉ�����)
	
	info->cmdfunc  = cmdfunc;		// ���s�֐�(cmdfunc)�̓o�^
	info->reffunc  = reffunc;		// �Q�Ɗ֐�(reffunc)�̓o�^
	info->termfunc = termfunc;		// �I���֐�(termfunc)�̓o�^
	
	// �ϐ��^�̓o�^
	registvar( -1, reinterpret_cast<HSPVAR_COREFUNC>( HspVarCaller_init ) );
	
	return;
}


//###############################################
//        �G���g���[�|�C���g�֐�
//###############################################
BOOL WINAPI DllMain(HINSTANCE hInstance, DWORD fdwReason, PVOID pvReserved)
{
	return TRUE;
}
